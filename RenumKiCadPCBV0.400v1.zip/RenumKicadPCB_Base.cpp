///////////////////////////////////////////////////////////////////////////
// C++ code generated with wxFormBuilder (version Oct 26 2018)
// http://www.wxformbuilder.org/
//
// PLEASE DO *NOT* EDIT THIS FILE!
///////////////////////////////////////////////////////////////////////////

#include "RenumKicadPCB_Base.h"

///////////////////////////////////////////////////////////////////////////

RenumKicadPCB_Base::RenumKicadPCB_Base( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxFrame( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	this->SetBackgroundColour( wxSystemSettings::GetColour( wxSYS_COLOUR_WINDOW ) );

	m_menubar = new wxMenuBar( 0 );
	RenumMenuAbout = new wxMenu();
	wxMenuItem* SayAbout;
	SayAbout = new wxMenuItem( RenumMenuAbout, wxID_ANY, wxString( _("&About") ) , wxEmptyString, wxITEM_NORMAL );
	RenumMenuAbout->Append( SayAbout );

	m_menubar->Append( RenumMenuAbout, _("&About") );

	m_ReadMe = new wxMenu();
	wxMenuItem* SayReadMe;
	SayReadMe = new wxMenuItem( m_ReadMe, wxID_ANY, wxString( _("&Read") ) , wxEmptyString, wxITEM_NORMAL );
	m_ReadMe->Append( SayReadMe );

	m_menubar->Append( m_ReadMe, _("&Read Me") );

	this->SetMenuBar( m_menubar );

	wxBoxSizer* bMainSizer;
	bMainSizer = new wxBoxSizer( wxVERTICAL );

	wxBoxSizer* bSizerProjectFilename;
	bSizerProjectFilename = new wxBoxSizer( wxVERTICAL );

	wxStaticText* staticProjectFileName;
	staticProjectFileName = new wxStaticText( this, wxID_ANY, _("Project file:"), wxDefaultPosition, wxDefaultSize, 0 );
	staticProjectFileName->Wrap( -1 );
	bSizerProjectFilename->Add( staticProjectFileName, 0, wxLEFT|wxRIGHT, 5 );

	m_ProjectFile = new wxFilePickerCtrl( this, wxID_ANY, wxEmptyString, _("Select a KiCad project file (*.pro)"), _("*.pro"), wxDefaultPosition, wxDefaultSize, wxFLP_DEFAULT_STYLE );
	m_ProjectFile->SetToolTip( _("Select a valid KiCad project with PCB and root schematic with the name.\nNOTE: The PCB or SCH files associated with the project must not be open in KiCad!\n") );

	bSizerProjectFilename->Add( m_ProjectFile, 1, wxALL|wxEXPAND, 5 );


	bMainSizer->Add( bSizerProjectFilename, 0, wxEXPAND|wxTOP, 10 );

	wxFlexGridSizer* fgSizer1;
	fgSizer1 = new wxFlexGridSizer( 6, 4, 0, 0 );
	fgSizer1->SetFlexibleDirection( wxBOTH );
	fgSizer1->SetNonFlexibleGrowMode( wxFLEX_GROWMODE_NONE );

	m_TopSortDirText = new wxStaticText( this, wxID_ANY, _("Top Sort Direction"), wxDefaultPosition, wxDefaultSize, 0 );
	m_TopSortDirText->Wrap( -1 );
	m_TopSortDirText->SetToolTip( _("Set the direction of sort: Top to bottom, left to regith is as you read a book") );

	fgSizer1->Add( m_TopSortDirText, 0, wxALL, 5 );

	wxString m_TopSortDirChoices[] = { _("Top to bottom, left to right"), _("Top to bottom, right to left"), _("Bottom to top, left to right"), _("Bottom to top, right to left"), _("Left to right, top to bottom"), _("Left to right, bottom to top"), _("Right to left, top to bottom"), _("Right to left, bottom to top") };
	int m_TopSortDirNChoices = sizeof( m_TopSortDirChoices ) / sizeof( wxString );
	m_TopSortDir = new wxChoice( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, m_TopSortDirNChoices, m_TopSortDirChoices, 0 );
	m_TopSortDir->SetSelection( 0 );
	m_TopSortDir->SetForegroundColour( wxSystemSettings::GetColour( wxSYS_COLOUR_WINDOWTEXT ) );
	m_TopSortDir->SetBackgroundColour( wxSystemSettings::GetColour( wxSYS_COLOUR_HIGHLIGHTTEXT ) );

	fgSizer1->Add( m_TopSortDir, 0, wxALL, 5 );

	m_BottomSortDirText = new wxStaticText( this, wxID_ANY, _("Bottom Sort Direction"), wxDefaultPosition, wxDefaultSize, 0 );
	m_BottomSortDirText->Wrap( -1 );
	m_BottomSortDirText->SetToolTip( _("Set sort direction if looking at the solder side of the board") );

	fgSizer1->Add( m_BottomSortDirText, 0, wxALL, 5 );

	wxString m_BottomSortDirChoices[] = { _("Top to bottom, left to right"), _("Top to bottom, right to left"), _("Bottom to top, left to right"), _("Bottom to top, right to left"), _("Left to right, top to bottom"), _("Left to right, bottom to top"), _("Right to left, top to bottom"), _("Right to left, bottom to top") };
	int m_BottomSortDirNChoices = sizeof( m_BottomSortDirChoices ) / sizeof( wxString );
	m_BottomSortDir = new wxChoice( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, m_BottomSortDirNChoices, m_BottomSortDirChoices, 0 );
	m_BottomSortDir->SetSelection( 1 );
	m_BottomSortDir->SetForegroundColour( wxSystemSettings::GetColour( wxSYS_COLOUR_WINDOWTEXT ) );
	m_BottomSortDir->SetBackgroundColour( wxSystemSettings::GetColour( wxSYS_COLOUR_HIGHLIGHTTEXT ) );

	fgSizer1->Add( m_BottomSortDir, 0, wxALL, 5 );

	m_TopRefDesStartText = new wxStaticText( this, wxID_ANY, _("Top Ref Des Start"), wxDefaultPosition, wxDefaultSize, 0 );
	m_TopRefDesStartText->Wrap( -1 );
	m_TopRefDesStartText->SetToolTip( _("Enter a number from 1-65,536") );

	fgSizer1->Add( m_TopRefDesStartText, 0, wxALL, 5 );

	m_TopRefDesStart = new wxTextCtrl( this, wxID_ANY, _("1"), wxDefaultPosition, wxSize( 100,-1 ), 0 );
	fgSizer1->Add( m_TopRefDesStart, 0, wxALL, 5 );

	m_BottomRefDesStartText = new wxStaticText( this, wxID_ANY, _("Bottom Ref Des Start\n(Blank continues from top)"), wxDefaultPosition, wxDefaultSize, 0 );
	m_BottomRefDesStartText->Wrap( -1 );
	m_BottomRefDesStartText->SetToolTip( _("Leave blank or zero, or enter a number greater than the highest reference designation on the component side. If there R100 is the highest component on the top side, this number must be 101 or more.\n") );

	fgSizer1->Add( m_BottomRefDesStartText, 0, wxALL, 5 );

	m_BottomRefDesStart = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 100,-1 ), 0 );
	fgSizer1->Add( m_BottomRefDesStart, 0, wxALL, 5 );

	m_TopPrefixText = new wxStaticText( this, wxID_ANY, _("Top Prefix"), wxDefaultPosition, wxDefaultSize, 0 );
	m_TopPrefixText->Wrap( -1 );
	m_TopPrefixText->SetToolTip( _("Optional prefix for component side reference designations (i.e. F_)") );

	fgSizer1->Add( m_TopPrefixText, 0, wxALL, 5 );

	m_TopPrefix = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 200,-1 ), 0 );
	fgSizer1->Add( m_TopPrefix, 0, wxALL, 1 );

	m_BottomPrefixText = new wxStaticText( this, wxID_ANY, _("Bottom Prefix"), wxDefaultPosition, wxDefaultSize, 0 );
	m_BottomPrefixText->Wrap( -1 );
	m_BottomPrefixText->SetToolTip( _("Optional prefix for solder side reference designations (i.e. B_)") );

	fgSizer1->Add( m_BottomPrefixText, 0, wxALL, 5 );

	m_BottomPrefix = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 200,-1 ), 0 );
	fgSizer1->Add( m_BottomPrefix, 0, wxALL, 1 );

	m_RemoveTopPrefix = new wxCheckBox( this, wxID_ANY, _("Remove Top Prefix"), wxDefaultPosition, wxDefaultSize, 0 );
	m_RemoveTopPrefix->SetToolTip( _("If checked will remove the component side prefix") );

	fgSizer1->Add( m_RemoveTopPrefix, 0, wxALL, 5 );

	m_staticText31 = new wxStaticText( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText31->Wrap( -1 );
	fgSizer1->Add( m_staticText31, 0, wxALL, 5 );

	m_RemoveBottomPrefix = new wxCheckBox( this, wxID_ANY, _("Remove Bottom Prefix"), wxDefaultPosition, wxDefaultSize, 0 );
	m_RemoveBottomPrefix->SetToolTip( _("If checked will remove the bottom side prefix") );

	fgSizer1->Add( m_RemoveBottomPrefix, 0, wxALL, 5 );

	m_staticText35 = new wxStaticText( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText35->Wrap( -1 );
	fgSizer1->Add( m_staticText35, 0, wxALL, 5 );

	m_SortGridText = new wxStaticText( this, wxID_ANY, _("Sort Grid"), wxDefaultPosition, wxDefaultSize, 0 );
	m_SortGridText->Wrap( -1 );
	m_SortGridText->SetToolTip( _("Sets the \"rounding grid\" for sort: usually smaller for less dense boards (try 1.0 to start)") );

	fgSizer1->Add( m_SortGridText, 0, wxALL, 5 );

	m_SortGrid = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxSize( 200,-1 ), 0 );
	fgSizer1->Add( m_SortGrid, 0, wxALL, 1 );

	m_SortOnModules = new wxRadioButton( this, wxID_ANY, _("Sort on Module Coordinates"), wxDefaultPosition, wxDefaultSize, 0 );
	m_SortOnModules->SetValue( true );
	m_SortOnModules->SetToolTip( _("Sort on the origin of the module") );

	fgSizer1->Add( m_SortOnModules, 0, wxALL, 5 );

	m_SortOnRefDes = new wxRadioButton( this, wxID_ANY, _("Sort on Ref Des Coordinates"), wxDefaultPosition, wxDefaultSize, 0 );
	m_SortOnRefDes->SetToolTip( _("Sort on the origin of the reference designation of the module") );

	fgSizer1->Add( m_SortOnRefDes, 0, wxALL, 5 );

	m_WriteChangeFile = new wxCheckBox( this, wxID_ANY, _("Write change file"), wxDefaultPosition, wxDefaultSize, 0 );
	m_WriteChangeFile->SetToolTip( _("Write a \"Was/Is\" file with format Was->Is") );

	fgSizer1->Add( m_WriteChangeFile, 0, wxALL, 5 );

	m_staticText36 = new wxStaticText( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText36->Wrap( -1 );
	fgSizer1->Add( m_staticText36, 0, wxALL, 5 );

	m_staticText37 = new wxStaticText( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText37->Wrap( -1 );
	fgSizer1->Add( m_staticText37, 0, wxALL, 5 );

	m_WriteLogFile = new wxCheckBox( this, wxID_ANY, _("Generate log file"), wxDefaultPosition, wxDefaultSize, 0 );
	m_WriteLogFile->SetToolTip( _("Generate a log file (useful for debugging)") );

	fgSizer1->Add( m_WriteLogFile, 0, wxALL, 5 );


	bMainSizer->Add( fgSizer1, 1, wxEXPAND, 5 );

	wxBoxSizer* bLowerSizer;
	bLowerSizer = new wxBoxSizer( wxVERTICAL );

	bLowerSizer->SetMinSize( wxSize( 660,250 ) );
	m_MessageWindow = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE|wxTE_RICH|wxTE_RICH2 );
	bLowerSizer->Add( m_MessageWindow, 1, wxALIGN_TOP|wxALL|wxEXPAND, 5 );


	bMainSizer->Add( bLowerSizer, 1, wxEXPAND, 1 );

	wxBoxSizer* bSizer9;
	bSizer9 = new wxBoxSizer( wxHORIZONTAL );

	wxGridSizer* gSizer1;
	gSizer1 = new wxGridSizer( 0, 4, 0, 0 );

	m_RenumberButton = new wxButton( this, wxID_ANY, _("Renumber"), wxDefaultPosition, wxDefaultSize, 0 );
	m_RenumberButton->SetToolTip( _("Renumber the board and back-annotate the schematics") );

	gSizer1->Add( m_RenumberButton, 0, wxALL, 5 );

	m_AccessTextFunctions = new wxButton( this, wxID_ANY, _("Text Functions"), wxDefaultPosition, wxDefaultSize, 0 );
	m_AccessTextFunctions->SetToolTip( _("Open the Text Function dialog") );

	gSizer1->Add( m_AccessTextFunctions, 0, wxALL, 5 );

	m_staticText38 = new wxStaticText( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0 );
	m_staticText38->Wrap( -1 );
	gSizer1->Add( m_staticText38, 0, wxALL, 5 );

	m_ExitButton = new wxButton( this, wxID_ANY, _("Exit"), wxDefaultPosition, wxDefaultSize, 0 );
	m_ExitButton->SetToolTip( _("Exit without saving the parameters") );

	gSizer1->Add( m_ExitButton, 0, wxALIGN_RIGHT|wxALL, 5 );


	bSizer9->Add( gSizer1, 1, wxEXPAND, 5 );


	bMainSizer->Add( bSizer9, 0, wxEXPAND|wxLEFT, 5 );


	this->SetSizer( bMainSizer );
	this->Layout();

	this->Centre( wxBOTH );

	// Connect Events
	this->Connect( wxEVT_SIZE, wxSizeEventHandler( RenumKicadPCB_Base::MainSize ) );
	RenumMenuAbout->Bind(wxEVT_COMMAND_MENU_SELECTED, wxCommandEventHandler( RenumKicadPCB_Base::SayAbout ), this, SayAbout->GetId());
	m_ReadMe->Bind(wxEVT_COMMAND_MENU_SELECTED, wxCommandEventHandler( RenumKicadPCB_Base::SayReadMe ), this, SayReadMe->GetId());
	m_ProjectFile->Connect( wxEVT_COMMAND_FILEPICKER_CHANGED, wxFileDirPickerEventHandler( RenumKicadPCB_Base::ProjectFileSel ), NULL, this );
	m_RenumberButton->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( RenumKicadPCB_Base::OnRenumberClick ), NULL, this );
	m_AccessTextFunctions->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( RenumKicadPCB_Base::AccessText ), NULL, this );
	m_ExitButton->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( RenumKicadPCB_Base::OKDone ), NULL, this );
}

RenumKicadPCB_Base::~RenumKicadPCB_Base()
{
	// Disconnect Events
	this->Disconnect( wxEVT_SIZE, wxSizeEventHandler( RenumKicadPCB_Base::MainSize ) );
	m_ProjectFile->Disconnect( wxEVT_COMMAND_FILEPICKER_CHANGED, wxFileDirPickerEventHandler( RenumKicadPCB_Base::ProjectFileSel ), NULL, this );
	m_RenumberButton->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( RenumKicadPCB_Base::OnRenumberClick ), NULL, this );
	m_AccessTextFunctions->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( RenumKicadPCB_Base::AccessText ), NULL, this );
	m_ExitButton->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( RenumKicadPCB_Base::OKDone ), NULL, this );

}

ReadMeDialog_Base::ReadMeDialog_Base( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );

	wxBoxSizer* bSizer6;
	bSizer6 = new wxBoxSizer( wxVERTICAL );

	ReadMeBox = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE );
	bSizer6->Add( ReadMeBox, 1, wxALL|wxEXPAND, 5 );

	CloseReadMeDialog = new wxButton( this, wxID_ANY, _("Close"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer6->Add( CloseReadMeDialog, 0, wxALIGN_CENTER|wxALL, 5 );


	this->SetSizer( bSizer6 );
	this->Layout();

	this->Centre( wxBOTH );

	// Connect Events
	CloseReadMeDialog->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( ReadMeDialog_Base::CloseReadMe ), NULL, this );
}

ReadMeDialog_Base::~ReadMeDialog_Base()
{
	// Disconnect Events
	CloseReadMeDialog->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( ReadMeDialog_Base::CloseReadMe ), NULL, this );

}

AboutDialog_Base::AboutDialog_Base( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );

	wxBoxSizer* bSizer6;
	bSizer6 = new wxBoxSizer( wxVERTICAL );

	AboutBox = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE );
	bSizer6->Add( AboutBox, 1, wxALL|wxEXPAND, 5 );

	CloseAboutDialog = new wxButton( this, wxID_ANY, _("Close"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer6->Add( CloseAboutDialog, 0, wxALIGN_CENTER|wxALL, 5 );


	this->SetSizer( bSizer6 );
	this->Layout();

	this->Centre( wxBOTH );

	// Connect Events
	CloseAboutDialog->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( AboutDialog_Base::CloseAbout ), NULL, this );
}

AboutDialog_Base::~AboutDialog_Base()
{
	// Disconnect Events
	CloseAboutDialog->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( AboutDialog_Base::CloseAbout ), NULL, this );

}

ContinueAbort_Base::ContinueAbort_Base( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	this->SetFont( wxFont( wxNORMAL_FONT->GetPointSize(), wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD, false, wxEmptyString ) );

	wxBoxSizer* bSizer99;
	bSizer99 = new wxBoxSizer( wxHORIZONTAL );

	wxStaticBoxSizer* sbErrorAbort;
	sbErrorAbort = new wxStaticBoxSizer( new wxStaticBox( this, wxID_ANY, _("Errors found: continue?") ), wxHORIZONTAL );

	m_Continue = new wxButton( sbErrorAbort->GetStaticBox(), wxID_ANY, _("Write Files Anyway"), wxDefaultPosition, wxDefaultSize, 0 );
	sbErrorAbort->Add( m_Continue, 0, wxALIGN_LEFT|wxALL, 5 );

	m_Abort = new wxButton( sbErrorAbort->GetStaticBox(), wxID_ANY, _("DIscard Changes"), wxDefaultPosition, wxDefaultSize, 0 );
	sbErrorAbort->Add( m_Abort, 0, wxALIGN_RIGHT|wxALL, 5 );


	bSizer99->Add( sbErrorAbort, 1, wxALIGN_CENTER|wxEXPAND, 5 );


	this->SetSizer( bSizer99 );
	this->Layout();

	this->Centre( wxBOTH );

	// Connect Events
	m_Continue->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( ContinueAbort_Base::ErrorContinue ), NULL, this );
	m_Abort->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( ContinueAbort_Base::ErrorAbort ), NULL, this );
}

ContinueAbort_Base::~ContinueAbort_Base()
{
	// Disconnect Events
	m_Continue->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( ContinueAbort_Base::ErrorContinue ), NULL, this );
	m_Abort->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( ContinueAbort_Base::ErrorAbort ), NULL, this );

}

Abort_Base::Abort_Base( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );
	this->SetFont( wxFont( wxNORMAL_FONT->GetPointSize(), wxFONTFAMILY_DEFAULT, wxFONTSTYLE_NORMAL, wxFONTWEIGHT_BOLD, false, wxEmptyString ) );

	wxBoxSizer* bSizer99;
	bSizer99 = new wxBoxSizer( wxHORIZONTAL );

	m_Continue = new wxButton( this, wxID_ANY, _("OK Try Again"), wxDefaultPosition, wxDefaultSize, 0 );
	bSizer99->Add( m_Continue, 0, wxALIGN_CENTER|wxALL, 5 );


	this->SetSizer( bSizer99 );
	this->Layout();

	this->Centre( wxBOTH );

	// Connect Events
	m_Continue->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Abort_Base::ErrorContinue ), NULL, this );
}

Abort_Base::~Abort_Base()
{
	// Disconnect Events
	m_Continue->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( Abort_Base::ErrorContinue ), NULL, this );

}

TextFunctions_Base::TextFunctions_Base( wxWindow* parent, wxWindowID id, const wxString& title, const wxPoint& pos, const wxSize& size, long style ) : wxDialog( parent, id, title, pos, size, style )
{
	this->SetSizeHints( wxDefaultSize, wxDefaultSize );

	wxBoxSizer* bSizer8;
	bSizer8 = new wxBoxSizer( wxVERTICAL );

	wxFlexGridSizer* fgSizer2;
	fgSizer2 = new wxFlexGridSizer( 0, 2, 0, 0 );
	fgSizer2->SetFlexibleDirection( wxBOTH );
	fgSizer2->SetNonFlexibleGrowMode( wxFLEX_GROWMODE_SPECIFIED );

	m_TextFieldtoModify = new wxStaticText( this, wxID_ANY, _("Text Field to Modify"), wxDefaultPosition, wxDefaultSize, 0 );
	m_TextFieldtoModify->Wrap( -1 );
	m_TextFieldtoModify->SetToolTip( _("This field on this layer will be acted on") );

	fgSizer2->Add( m_TextFieldtoModify, 0, wxALL, 5 );

	wxString m_TextFieldChoiceChoices[] = { _("reference  on F.Silks") };
	int m_TextFieldChoiceNChoices = sizeof( m_TextFieldChoiceChoices ) / sizeof( wxString );
	m_TextFieldChoice = new wxChoice( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, m_TextFieldChoiceNChoices, m_TextFieldChoiceChoices, 0 );
	m_TextFieldChoice->SetSelection( 0 );
	fgSizer2->Add( m_TextFieldChoice, 0, wxALL, 5 );

	m_SetTextAngle = new wxRadioButton( this, wxID_ANY, _("Set Text Angle"), wxDefaultPosition, wxDefaultSize, 0 );
	m_SetTextAngle->SetToolTip( _("Set all Text Field selected above to this angle (0 is horizontal)") );

	fgSizer2->Add( m_SetTextAngle, 0, wxALL, 5 );

	m_TextAngle = new wxTextCtrl( this, wxID_ANY, _("0.0000"), wxDefaultPosition, wxDefaultSize, 0 );
	fgSizer2->Add( m_TextAngle, 0, wxALL, 5 );

	m_Overlay = new wxRadioButton( this, wxID_ANY, _("Overlay WIth This FIeld"), wxDefaultPosition, wxDefaultSize, 0 );
	m_Overlay->SetToolTip( _("Try and center the Text Field to Modfy on the module") );

	fgSizer2->Add( m_Overlay, 0, wxALL, 5 );

	wxString m_OverlayReferenceChoiceChoices[] = { _("reference  on F.Silks") };
	int m_OverlayReferenceChoiceNChoices = sizeof( m_OverlayReferenceChoiceChoices ) / sizeof( wxString );
	m_OverlayReferenceChoice = new wxChoice( this, wxID_ANY, wxDefaultPosition, wxDefaultSize, m_OverlayReferenceChoiceNChoices, m_OverlayReferenceChoiceChoices, 0 );
	m_OverlayReferenceChoice->SetSelection( 0 );
	fgSizer2->Add( m_OverlayReferenceChoice, 0, wxALL, 5 );

	m_CenterOnModule = new wxRadioButton( this, wxID_ANY, _("Center On Module"), wxDefaultPosition, wxDefaultSize, 0 );
	m_CenterOnModule->SetToolTip( _("Try and center the Text Field to Modfy on the module") );

	fgSizer2->Add( m_CenterOnModule, 0, wxALL, 5 );


	bSizer8->Add( fgSizer2, 1, wxEXPAND, 5 );

	wxBoxSizer* bSizer91;
	bSizer91 = new wxBoxSizer( wxHORIZONTAL );

	wxGridSizer* gSizer3;
	gSizer3 = new wxGridSizer( 0, 3, 0, 0 );

	m_UpdateTextButton = new wxButton( this, wxID_ANY, _("Update Text Fields"), wxDefaultPosition, wxDefaultSize, 0 );
	m_UpdateTextButton->SetToolTip( _("Update Text Field to Modify as indicated (cannot be undone)") );

	gSizer3->Add( m_UpdateTextButton, 0, wxALL, 5 );

	m_SaveTextButton = new wxButton( this, wxID_ANY, _("Save Changes"), wxDefaultPosition, wxDefaultSize, 0 );
	m_SaveTextButton->SetToolTip( _("Save the changes I made to the PCB and write them out (last chance!)") );

	gSizer3->Add( m_SaveTextButton, 0, wxALIGN_CENTER_HORIZONTAL|wxALL, 5 );

	m_ExitTextButton = new wxButton( this, wxID_ANY, _("Exit"), wxPoint( -1,-1 ), wxDefaultSize, 0 );
	m_ExitTextButton->SetToolTip( _("Exit without updating the PCB") );

	gSizer3->Add( m_ExitTextButton, 0, wxALIGN_RIGHT|wxALL|wxRIGHT, 5 );


	bSizer91->Add( gSizer3, 1, wxEXPAND, 5 );


	bSizer8->Add( bSizer91, 0, wxEXPAND, 5 );

	wxBoxSizer* bSizer9;
	bSizer9 = new wxBoxSizer( wxVERTICAL );

	m_TextMessageWindow = new wxTextCtrl( this, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxTE_MULTILINE|wxTE_RICH|wxTE_RICH2 );
	bSizer9->Add( m_TextMessageWindow, 10, wxALIGN_TOP|wxALL|wxEXPAND, 5 );


	bSizer8->Add( bSizer9, 1, wxEXPAND, 5 );


	this->SetSizer( bSizer8 );
	this->Layout();

	this->Centre( wxBOTH );

	// Connect Events
	this->Connect( wxEVT_SIZE, wxSizeEventHandler( TextFunctions_Base::TextSize ) );
	m_TextAngle->Connect( wxEVT_COMMAND_TEXT_UPDATED, wxCommandEventHandler( TextFunctions_Base::SelectTextAngle ), NULL, this );
	m_OverlayReferenceChoice->Connect( wxEVT_COMMAND_CHOICE_SELECTED, wxCommandEventHandler( TextFunctions_Base::SelectOverlay ), NULL, this );
	m_UpdateTextButton->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( TextFunctions_Base::UpdateTextFieldCLick ), NULL, this );
	m_SaveTextButton->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( TextFunctions_Base::SaveChangesClick ), NULL, this );
	m_ExitTextButton->Connect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( TextFunctions_Base::ExitTextFieldClick ), NULL, this );
}

TextFunctions_Base::~TextFunctions_Base()
{
	// Disconnect Events
	this->Disconnect( wxEVT_SIZE, wxSizeEventHandler( TextFunctions_Base::TextSize ) );
	m_TextAngle->Disconnect( wxEVT_COMMAND_TEXT_UPDATED, wxCommandEventHandler( TextFunctions_Base::SelectTextAngle ), NULL, this );
	m_OverlayReferenceChoice->Disconnect( wxEVT_COMMAND_CHOICE_SELECTED, wxCommandEventHandler( TextFunctions_Base::SelectOverlay ), NULL, this );
	m_UpdateTextButton->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( TextFunctions_Base::UpdateTextFieldCLick ), NULL, this );
	m_SaveTextButton->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( TextFunctions_Base::SaveChangesClick ), NULL, this );
	m_ExitTextButton->Disconnect( wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler( TextFunctions_Base::ExitTextFieldClick ), NULL, this );

}
